﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Form1 : Form
    {
        private readonly DatabaseSingleton databaseSingleton = DatabaseSingleton.Instance;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.tableTableAdapter.Fill(this.databaseDataSet1.Table);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "SELECT * FROM [dbo].[Table]";

                using (SqlDataReader reader = databaseSingleton.ExecuteQuery(query))
                {
                    Form2 form2 = new Form2();
                    form2.ListView1.Items.Clear();

                    while (reader.Read())
                    {
                        string[] row = { reader["Id"].ToString(), reader["Doc"].ToString(), reader["Info"].ToString() };
                        ListViewItem item = new ListViewItem(row);
                        form2.ListView1.Items.Add(item);

                        Console.WriteLine($"Added item: {item.Text}, {item.SubItems[1].Text}, {item.SubItems[2].Text}");
                    }

                    form2.Show();
                }

                MessageBox.Show("Дані завантажено");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка: " + ex.Message);
            }
        }
    }
}
