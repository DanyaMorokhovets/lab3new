﻿using System;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        public ListView ListView1
        {
            get { return listView1; }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            listView1.View = View.Details;
            listView1.GridLines = true;

            listView1.Columns.Add("ID", 50, HorizontalAlignment.Left);
            listView1.Columns.Add("Doc", 150, HorizontalAlignment.Left);
            listView1.Columns.Add("Info", 150, HorizontalAlignment.Left);

            Console.WriteLine($"ListView items count: {listView1.Items.Count}"); //Перевірка даних
        }
    }
}
