﻿using System;
using System.Data.SqlClient;

namespace Lab3
{
    public class DatabaseSingleton
    {
        private static readonly Lazy<DatabaseSingleton> instance = new Lazy<DatabaseSingleton>(() => new DatabaseSingleton());

        private readonly string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename = |DataDirectory|\\Database.mdf;;Integrated Security=True";
        private SqlConnection connection;

        public static DatabaseSingleton Instance => instance.Value;

        private DatabaseSingleton()
        {
            InitializeConnection();
        }

        private void InitializeConnection()
        {
            connection = new SqlConnection(connectionString);
        }

        public SqlConnection GetConnection()
        {
            try
            {
                if (connection.State != System.Data.ConnectionState.Open)
                {
                    connection.Open();
                }
                return connection;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error opening database connection: {ex.Message}");
                throw;
            }
        }

        public void CloseConnection()
        {
            if (connection.State != System.Data.ConnectionState.Closed)
            {
                connection.Close();
            }
        }

        public SqlDataReader ExecuteQuery(string query)
        {
            using (SqlCommand command = new SqlCommand(query, GetConnection()))
            {
                return command.ExecuteReader();
            }
        }
    }
}
